import { S3Client, GetObjectCommand, PutObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import Papa from 'papaparse';

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });

export const handler = async (event) => {
    try {
        const record = event.Records[0];
        const bucket = record.s3.bucket.name;
        const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
        
        console.log(`Processing: ${key} from ${bucket}`);
        
        // Determine order_type from filename
        const fileName = key.split('/').pop();
        const fileNameWithoutExt = fileName.replace(/\.[^/.]+$/, '');
        
        let orderType;
        if (fileNameWithoutExt.endsWith('_e')) {
            orderType = 'E';
        } else if (fileNameWithoutExt.endsWith('_s')) {
            orderType = 'S';
        } else {
            throw new Error(`Invalid filename format. Must end with _e or _s: ${fileName}`);
        }
        
        // Download CSV from Bucket 1
        const getCommand = new GetObjectCommand({
            Bucket: bucket,
            Key: key
        });
        
        const response = await s3Client.send(getCommand);
        const csvContent = await streamToString(response.Body);
        
        // Parse CSV
        const parsed = await new Promise((resolve, reject) => {
            Papa.parse(csvContent, {
                header: true,
                dynamicTyping: true,
                skipEmptyLines: true,
                complete: (results) => resolve(results),
                error: (error) => reject(error)
            });
        });
        
        // Add order_type and timestamp to each record
        const transformedData = parsed.data.map(row => ({
            ...row,
            order_type: orderType,
            processed_timestamp: new Date().toISOString()
        }));
        
        console.log(`Transformed ${transformedData.length} records`);
        
        // Write JSON to Bucket 2
        const jsonKey = fileName.replace('.csv', '.json');
        const putCommand = new PutObjectCommand({
            Bucket: process.env.JSON_BUCKET,
            Key: jsonKey,
            Body: JSON.stringify(transformedData, null, 2),
            ContentType: 'application/json'
        });
        
        await s3Client.send(putCommand);
        console.log(`JSON written to ${process.env.JSON_BUCKET}/${jsonKey}`);
        
        // Optional: Delete CSV from upload bucket after processing
        const deleteCommand = new DeleteObjectCommand({
            Bucket: bucket,
            Key: key
        });
        
        await s3Client.send(deleteCommand);
        console.log(`Deleted ${key} from upload bucket`);
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'CSV transformed to JSON',
                records: transformedData.length,
                output: `${process.env.JSON_BUCKET}/${jsonKey}`
            })
        };
        
    } catch (error) {
        console.error('ERROR:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
        };
    }
};

async function streamToString(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks).toString('utf-8');
}