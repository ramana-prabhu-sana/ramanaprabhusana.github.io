import { S3Client, ListObjectsV2Command, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });

export const handler = async (event) => {
    try {
        console.log('Generating HTML report from all JSON files');
        
        // List all JSON files in Bucket 2
        const listCommand = new ListObjectsV2Command({
            Bucket: process.env.JSON_BUCKET
        });
        
        const listResult = await s3Client.send(listCommand);
        const jsonFiles = listResult.Contents?.filter(obj => obj.Key.endsWith('.json')) || [];
        
        console.log(`Found ${jsonFiles.length} JSON files`);
        
        // Read all JSON files
        let allOrders = [];
        
        for (const file of jsonFiles) {
            const getCommand = new GetObjectCommand({
                Bucket: process.env.JSON_BUCKET,
                Key: file.Key
            });
            
            const response = await s3Client.send(getCommand);
            const content = await streamToString(response.Body);
            const orders = JSON.parse(content);
            allOrders = allOrders.concat(orders);
        }
        
        console.log(`Total orders across all files: ${allOrders.length}`);
        
        // Calculate statistics
        const stats = calculateStatistics(allOrders);
        
        // Generate HTML report
        const html = generateHTMLReport(stats);
        
        // Write HTML to Bucket 3
        const putCommand = new PutObjectCommand({
            Bucket: process.env.REPORT_BUCKET,
            Key: 'summary_report.html',
            Body: html,
            ContentType: 'text/html'
        });
        
        await s3Client.send(putCommand);
        console.log('HTML report written to report bucket');
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Report generated',
                total_orders: allOrders.length,
                report_url: `https://${process.env.REPORT_BUCKET}.s3.amazonaws.com/summary_report.html`
            })
        };
        
    } catch (error) {
        console.error('ERROR:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
        };
    }
};

function calculateStatistics(orders) {
    const ecommerceOrders = orders.filter(o => o.order_type === 'E');
    const storeOrders = orders.filter(o => o.order_type === 'S');
    
    const totalRevenue = orders.reduce((sum, o) => sum + (o.subtotal || 0), 0);
    const ecommerceRevenue = ecommerceOrders.reduce((sum, o) => sum + (o.subtotal || 0), 0);
    const storeRevenue = storeOrders.reduce((sum, o) => sum + (o.subtotal || 0), 0);
    
    // Top products
    const productSales = {};
    orders.forEach(o => {
        const key = o.sku;
        if (!productSales[key]) {
            productSales[key] = {
                sku: o.sku,
                product_name: o.product_name,
                units: 0,
                revenue: 0
            };
        }
        productSales[key].units += o.quantity || 0;
        productSales[key].revenue += o.subtotal || 0;
    });
    
    const topProducts = Object.values(productSales)
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 5);
    
    // Top states (for e-commerce)
    const stateSales = {};
    ecommerceOrders.forEach(o => {
        if (o.state) {
            if (!stateSales[o.state]) {
                stateSales[o.state] = { count: 0, revenue: 0 };
            }
            stateSales[o.state].count++;
            stateSales[o.state].revenue += o.subtotal || 0;
        }
    });
    
    const topStates = Object.entries(stateSales)
        .map(([state, data]) => ({ state, ...data }))
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 5);
    
    return {
        totalOrders: orders.length,
        ecommerceCount: ecommerceOrders.length,
        storeCount: storeOrders.length,
        totalRevenue: totalRevenue.toFixed(2),
        ecommerceRevenue: ecommerceRevenue.toFixed(2),
        storeRevenue: storeRevenue.toFixed(2),
        avgOrderValue: (totalRevenue / orders.length).toFixed(2),
        topProducts,
        topStates,
        generatedAt: new Date().toISOString()
    };
}

function generateHTMLReport(stats) {
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Analytics Report</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .timestamp {
            opacity: 0.9;
            font-size: 14px;
        }
        
        .metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 30px;
        }
        
        .metric-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }
        
        .metric-label {
            color: #6c757d;
            font-size: 14px;
            margin-bottom: 5px;
        }
        
        .metric-value {
            font-size: 28px;
            font-weight: bold;
            color: #667eea;
        }
        
        .section {
            padding: 0 30px 30px 30px;
        }
        
        .section h2 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        th {
            background: #667eea;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 12px;
            border-bottom: 1px solid #e9ecef;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .revenue {
            color: #28a745;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Order Analytics Report</h1>
            <p class="timestamp">Generated: ${new Date(stats.generatedAt).toLocaleString()}</p>
        </div>
        
        <div class="metrics">
            <div class="metric-card">
                <div class="metric-label">Total Orders</div>
                <div class="metric-value">${stats.totalOrders}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Total Revenue</div>
                <div class="metric-value">$${stats.totalRevenue}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">E-commerce Orders</div>
                <div class="metric-value">${stats.ecommerceCount}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Store Orders</div>
                <div class="metric-value">${stats.storeCount}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">E-commerce Revenue</div>
                <div class="metric-value">$${stats.ecommerceRevenue}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Store Revenue</div>
                <div class="metric-value">$${stats.storeRevenue}</div>
            </div>
        </div>
        
        <div class="section">
            <h2>Top 5 Products by Revenue</h2>
            <table>
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Product Name</th>
                        <th>Units Sold</th>
                        <th>Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    ${stats.topProducts.map(p => `
                        <tr>
                            <td>${p.sku}</td>
                            <td>${p.product_name}</td>
                            <td>${p.units}</td>
                            <td class="revenue">$${p.revenue.toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
        
        ${stats.topStates.length > 0 ? `
        <div class="section">
            <h2>Top 5 States by Revenue (E-commerce)</h2>
            <table>
                <thead>
                    <tr>
                        <th>State</th>
                        <th>Orders</th>
                        <th>Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    ${stats.topStates.map(s => `
                        <tr>
                            <td>${s.state}</td>
                            <td>${s.count}</td>
                            <td class="revenue">$${s.revenue.toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
        ` : ''}
    </div>
</body>
</html>
    `;
}

async function streamToString(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks).toString('utf-8');
}